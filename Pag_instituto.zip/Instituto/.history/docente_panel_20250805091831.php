<?php
// docente_panel.php
session_start();

// Verificar autenticación
if (!isset($_SESSION['user_nie'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

$conn = conectarDB();
$docente_nie = $_SESSION['user_nie'];
$docente_nombre = $_SESSION['user_nombre'] . ' ' . $_SESSION['user_apellido'];

// Obtener información del docente
$docente_info = [];
$stmt = $conn->prepare("SELECT * FROM personal_registrado WHERE NIE = ?");
$stmt->bind_param("i", $docente_nie);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 1) {
    $docente_info = $result->fetch_assoc();
} else {
    session_destroy();
    header("Location: login.php?error=usuario_no_encontrado");
    exit();
}
$stmt->close();

// Obtener materias
$materias = [];
$stmt = $conn->prepare("SELECT DISTINCT MATERIA FROM personal_registrado WHERE NIE = ? AND MATERIA IS NOT NULL");
$stmt->bind_param("i", $docente_nie);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $materias[] = $row['MATERIA'];
}
$stmt->close();

// Obtener estudiantes
$estudiantes = [];
if (!empty($materias)) {
    $placeholders = str_repeat('?,', count($materias) - 1) . '?';
    $types = str_repeat('s', count($materias));
    
    $stmt = $conn->prepare("SELECT NIE, NOMBRE, APELLIDO, MATERIA FROM personal_registrado 
                            WHERE MATERIA IN ($placeholders) AND ROL = 'Estudiante'");
    $stmt->bind_param($types, ...$materias);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $estudiantes[$row['MATERIA']][] = $row;
    }
    $stmt->close();
}

// Obtener notas
$notas = [];
$stmt = $conn->prepare("SELECT * FROM notas WHERE DOCENTE = ?");
$stmt->bind_param("s", $docente_nombre);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $notas[$row['NIE']][$row['MATERIA']] = $row;
}
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="es"> <!-- ✅ CORREGIDO -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Docente - <?php echo htmlspecialchars($docente_info['ESPECIALIDAD'] ?? 'Docente'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --color-primary: #0056b3;
            --color-secondary: #1e293b;
            --color-accent: #0ea5e9;
            --color-danger: #dc3545;
            --color-success: #28a745;
            --color-warning: #ffc107;
            --color-text: #333333;
            --color-light: #f8f9fa;
            --color-border: #dee2e6;
            --sidebar-width: 280px;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f7fa;
            color: var(--color-text);
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: var(--sidebar-width);
            background: var(--color-primary);
            color: white;
            height: 100vh;
            position: fixed;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            z-index: 1000;
        }
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }
        .teacher-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        .teacher-img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--color-secondary);
            margin-bottom: 1rem;
        }
        .teacher-name {
            font-weight: 500;
            font-size: 1.1rem;
            margin-bottom: 0.25rem;
        }
        .teacher-position {
            font-size: 0.85rem;
            background-color: var(--color-secondary);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            margin-bottom: 0.5rem;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .menu-item {
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s;
        }
        .menu-item:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }
        .menu-item.active {
            background-color: var(--color-primary);
        }
        .menu-link {
            display: flex;
            align-items: center;
            padding: 1rem 1.5rem;
            color: white;
            text-decoration: none;
            font-weight: 400;
        }
        .menu-link:hover {
            color: white;
        }
        .menu-icon {
            margin-right: 10px;
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            flex: 1;
            padding: 2rem;
            background-color: #f8fafc;
        }
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--color-border);
        }
        .page-title {
            font-size: 1.75rem;
            color: var(--color-secondary);
            margin: 0;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
        }
        .card-header {
            background-color: white;
            border-bottom: 1px solid var(--color-border);
            font-weight: 500;
            padding: 1.25rem 1.5rem;
            border-radius: 10px 10px 0 0 !important;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .table th {
            background-color: #f8f9fa;
            font-weight: 500;
            color: var(--color-secondary);
        }
        .btn-icon {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            border-radius: 6px;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="teacher-profile">
                <img src="imagenes\Logo_del_Gobierno_de_El_Salvador_(2019).svg.png" alt="Foto del docente" class="teacher-img">
                <div class="teacher-name"><?php echo htmlspecialchars($_SESSION['user_nombre'] . ' ' . $_SESSION['user_apellido']); ?></div>
                <div class="teacher-position"><?php echo htmlspecialchars($docente_info['ROL']); ?></div>
                <div class="teacher-id">NIE: <?php echo htmlspecialchars($_SESSION['user_nie']); ?></div>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-item active" data-target="dashboard">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-speedometer2"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="menu-item" data-target="datos">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-person"></i>
                    <span>Datos personales</span>
                </a>
            </li>
            <li class="menu-item" data-target="asistencias">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-clipboard-check"></i>
                    <span>Registro de asistencias</span>
                </a>
            </li>
            <li class="menu-item" data-target="notas">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-journal-text"></i>
                    <span>Registro de notas</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="logout.php" class="menu-link">
                    <i class="menu-icon bi bi-box-arrow-right"></i>
                    <span>Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </div>

    <div class="main-content">
        <div class="content-header">
            <h1 class="page-title">Dashboard</h1>
            <div class="date-info"><?php echo date('d/m/Y'); ?></div>
        </div>

        <div id="dashboard-content" class="content-section">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">Resumen de actividades</div>
                        <div class="card-body">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td>Materias asignadas</td>
                                        <td><?php echo count($materias); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Estudiantes a cargo</td>
                                        <td>
                                            <?php 
                                                $total = 0;
                                                foreach ($estudiantes as $lista) {
                                                    $total += count($lista);
                                                }
                                                echo $total;
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Próximas evaluaciones</td>
                                        <td>Consultar calendario</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">Calendario académico</div>
                        <div class="card-body">
                            <div class="mb-3"><strong>Hoy: <?php echo date('d/m/Y'); ?></strong></div>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span>Periodo de evaluaciones</span>
                                    <span class="badge bg-primary">15/05 - 20/05</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span>Entrega de planificaciones</span>
                                    <span class="badge bg-warning text-dark">Viernes</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mt-4">
                <div class="card-header">Materias asignadas</div>
                <div class="card-body">
                    <div class="row">
                        <?php foreach ($materias as $materia): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100">
                                <div class="card-header bg-primary text-white">
                                    <?php echo htmlspecialchars($materia); ?>
                                </div>
                                <div class="card-body">
                                    <p><strong>Estudiantes:</strong> <?php echo isset($estudiantes[$materia]) ? count($estudiantes[$materia]) : 0; ?></p>
                                    <a href="#notas-content" class="btn btn-sm btn-outline-primary" onclick="mostrarSeccion('notas')">Registrar notas</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="datos-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">Información personal</div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tbody>
                            <tr><th>Nombre completo</th><td><?php echo htmlspecialchars($docente_info['NOMBRE'] . ' ' . $docente_info['APELLIDO']); ?></td></tr>
                            <tr><th>NIE</th><td><?php echo htmlspecialchars($docente_info['NIE']); ?></td></tr>
                            <tr><th>Tutor de</th><td><?php echo htmlspecialchars($docente_info['ESPECIALIDAD'] . ''. $); ?></td></tr>
                            <tr><th>Módulo</th><td><?php echo htmlspecialchars($docente_info['MODULO']); ?></td></tr>
                            <tr><th>Materias</th><td><?php echo htmlspecialchars(implode(', ', $materias)); ?></td></tr>
                            <tr><th>Correo</th><td><?php echo htmlspecialchars($docente_info['CORREO']); ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div id="asistencias-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">
                    <span>Registro de asistencias</span>
                    <div>
                        <select class="form-select form-select-sm" id="select-materia-asistencia">
                            <?php foreach ($materias as $m): ?>
                            <option value="<?php echo htmlspecialchars($m); ?>"><?php echo htmlspecialchars($m); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="date" class="form-control form-control-sm" id="fecha-asistencia">
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>NIE</th>
                                <th>Estudiante</th>
                                <th>Asistencia</th>
                                <th>Observaciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($estudiantes[$materias[0]])): ?>
                                <?php foreach ($estudiantes[$materias[0]] as $e): ?>
                                <tr>
                                    <td><?php echo $e['NIE']; ?></td>
                                    <td><?php echo htmlspecialchars($e['NOMBRE'] . ' ' . $e['APELLIDO']); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-present">P</button>
                                            <button class="btn btn-absent">A</button>
                                            <button class="btn btn-justified">J</button>
                                        </div>
                                    </td>
                                    <td><input type="text" class="form-control form-control-sm" placeholder="Notas"></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="4" class="text-center">No hay estudiantes</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="text-end mt-3">
                        <button class="btn btn-primary" id="guardar-asistencias">Guardar</button>
                    </div>
                </div>
            </div>
        </div>

        <div id="notas-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">
                    <span>Registro de notas</span>
                    <div>
                        <select class="form-select form-select-sm" id="select-materia-notas">
                            <?php foreach ($materias as $m): ?>
                            <option value="<?php echo htmlspecialchars($m); ?>"><?php echo htmlspecialchars($m); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <select class="form-select form-select-sm" id="select-periodo">
                            <option value="1">Primer Periodo</option>
                            <option value="2">Segundo Periodo</option>
                            <option value="3">Tercer Periodo</option>
                            <option value="4">Cuarto Periodo</option>
                        </select>
                    </div>
                </div>
                <div class="card-body">
                    <form action="guardar_notas.php" method="POST">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>NIE</th>
                                    <th>Estudiante</th>
                                    <th>Nota</th>
                                    <th>Comentarios</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($estudiantes[$materias[0]])): ?>
                                    <?php foreach ($estudiantes[$materias[0]] as $e): ?>
                                    <tr>
                                        <td><?php echo $e['NIE']; ?></td>
                                        <td><?php echo htmlspecialchars($e['NOMBRE'] . ' ' . $e['APELLIDO']); ?></td>
                                        <td>
                                            <input type="number" min="0" max="10" step="0.01" 
                                                   name="notas[<?php echo $e['NIE']; ?>][nota]" 
                                                   value="<?php echo isset($notas[$e['NIE']][$materias[0]]['PERIODO_1']) ? $notas[$e['NIE']][$materias[0]]['PERIODO_1'] : ''; ?>" 
                                                   class="form-control" style="width: 80px;">
                                        </td>
                                        <td>
                                            <input type="text" name="notas[<?php echo $e['NIE']; ?>][comentario]" 
                                                   class="form-control" placeholder="Observaciones">
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="4" class="text-center">No hay estudiantes</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <input type="hidden" name="materia" value="<?php echo !empty($materias) ? $materias[0] : ''; ?>">
                        <input type="hidden" name="periodo" value="1">
                        <div class="text-end mt-3">
                            <button type="submit" class="btn btn-primary">Guardar notas</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const menuItems = document.querySelectorAll('.menu-item');
            const sections = document.querySelectorAll('.content-section');
            
            menuItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    if (this.querySelector('a').getAttribute('href') === 'logout.php') return;
                    e.preventDefault();
                    
                    menuItems.forEach(i => i.classList.remove('active'));
                    this.classList.add('active');
                    
                    sections.forEach(s => s.style.display = 'none');
                    
                    const target = this.getAttribute('data-target');
                    document.getElementById(`${target}-content`).style.display = 'block';
                    document.querySelector('.page-title').textContent = this.querySelector('span').textContent;
                });
            });
            
            // Mostrar dashboard por defecto
            document.querySelector('.menu-item.active').click();
        });

        function mostrarSeccion(seccion) {
            document.querySelectorAll('.content-section').forEach(s => s.style.display = 'none');
            document.getElementById(`${seccion}-content`).style.display = 'block';
            document.querySelector('.page-title').textContent = document.querySelector(`[data-target="${seccion}"] span`).textContent;
            document.querySelectorAll('.menu-item').forEach(i => i.classList.remove('active'));
            document.querySelector(`[data-target="${seccion}"]`).classList.add('active');
        }
    </script>
</body>
</html>