<?php
// admin_panel.php
require_once 'config.php';
session_start();

// Verificar autenticación
if (!isset($_SESSION['user_rol']) || $_SESSION['user_rol'] !== 'Administrador') {
    header("Location: login.php");
    exit();
}

$conn = conectarDB();

// Estadísticas
$usuarios = $conn->query("SELECT COUNT(*) as total FROM personal_registrado")->fetch_assoc()['total'];
$estudiantes = $conn->query("SELECT COUNT(*) as total FROM personal_registrado WHERE ROL = 'Estudiante'")->fetch_assoc()['total'];
$docentes = $conn->query("SELECT COUNT(*) as total FROM personal_registrado WHERE ROL = 'Docente'")->fetch_assoc()['total'];
$materias = $conn->query("SELECT COUNT(*) as total FROM materia")->fetch_assoc()['total'];

// Últimos registros
$actividad = $conn->query("
    SELECT 'Nuevo estudiante registrado' as accion, NIE as id, CONCAT(NOMBRE, ' ', APELLIDO) as nombre, NOW() as fecha 
    FROM personal_registrado 
    WHERE ROL = 'Estudiante' 
    ORDER BY NIE DESC 
    LIMIT 4
");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración - Sistema Académico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --color-primary: #0056b3;
            --color-secondary: #1e293b;
            --color-accent: #0ea5e9;
            --color-danger: #dc3545;
            --color-success: #28a745;
            --color-warning: #ffc107;
            --color-text: #333333;
            --color-light: #f8f9fa;
            --color-border: #dee2e6;
            --sidebar-width: 280px;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f7fa;
            color: var(--color-text);
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            color: white;
            height: 100vh;
            position: fixed;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            z-index: 1000;
        }
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }
        .admin-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        .admin-img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--color-accent);
            margin-bottom: 1rem;
        }
        .admin-name {
            font-weight: 500;
            font-size: 1.1rem;
            margin-bottom: 0.25rem;
        }
        .admin-role {
            font-size: 0.85rem;
            background-color: var(--color-danger);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            margin-bottom: 0.5rem;
        }
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .menu-item {
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s;
        }
        .menu-item:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }
        .menu-item.active {
            background-color: var(--color-primary);
        }
        .menu-link {
            display: flex;
            align-items: center;
            padding: 1rem 1.5rem;
            color: white;
            text-decoration: none;
            font-weight: 400;
        }
        .menu-icon {
            margin-right: 10px;
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            flex: 1;
            padding: 2rem;
            background-color: #f8fafc;
        }
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--color-border);
        }
        .page-title {
            font-size: 1.75rem;
            color: var(--color-secondary);
            margin: 0;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
        }
        .card-header {
            background-color: white;
            border-bottom: 1px solid var(--color-border);
            font-weight: 500;
            padding: 1.25rem 1.5rem;
            border-radius: 10px 10px 0 0 !important;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .table th {
            background-color: #f8f9fa;
            font-weight: 500;
            color: var(--color-secondary);
        }
        .search-box {
            position: relative;
            max-width: 300px;
        }
        .search-box .form-control {
            padding-left: 40px;
            border-radius: 20px;
        }
        .search-box .bi {
            position: absolute;
            left: 15px;
            top: 10px;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="admin-profile">
                <img src="imagenes\Logo_del_Gobierno_de_El_Salvador_(2019).svg.png" alt="Foto del administrador" class="admin-img">
                <div class="admin-name"><?php echo htmlspecialchars($_SESSION['user_nombre'] . ' ' . $_SESSION['user_apellido']); ?></div>
                <div class="admin-role">Administrador</div>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-item active" data-target="dashboard">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-speedometer2"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="menu-item" data-target="usuarios">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-people"></i>
                    <span>Control de Usuarios</span>
                </a>
            </li>
            <li class="menu-item" data-target="materias">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-journal-bookmark"></i>
                    <span>Gestión de Materias</span>
                </a>
            </li>
            <li class="menu-item" data-target="estudiantes">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-person-video2"></i>
                    <span>Registro de Estudiantes</span>
                </a>
            </li>
            <li class="menu-item" data-target="docentes">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-person-badge"></i>
                    <span>Registro de Docentes</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="logout.php" class="menu-link">
                    <i class="menu-icon bi bi-box-arrow-right"></i>
                    <span>Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="content-header">
            <h1 class="page-title">Dashboard</h1>
            <div class="date-info"><?php echo date('d/m/Y'); ?></div>
        </div>

        <!-- Dashboard -->
        <div id="dashboard-content" class="content-section">
            <div class="row">
                <div class="col-md-3 mb-4">
                    <div class="card border-primary">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-2">Usuarios</h6>
                                    <h3 class="mb-0"><?php echo $usuarios; ?></h3>
                                </div>
                                <div class="bg-primary bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-people text-primary" style="font-size: 1.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card border-success">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-2">Estudiantes</h6>
                                    <h3 class="mb-0"><?php echo $estudiantes; ?></h3>
                                </div>
                                <div class="bg-success bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-person-video2 text-success" style="font-size: 1.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card border-info">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-2">Docentes</h6>
                                    <h3 class="mb-0"><?php echo $docentes; ?></h3>
                                </div>
                                <div class="bg-info bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-person-badge text-info" style="font-size: 1.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card border-warning">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-2">Materias</h6>
                                    <h3 class="mb-0"><?php echo $materias; ?></h3>
                                </div>
                                <div class="bg-warning bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-journal-bookmark text-warning" style="font-size: 1.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">Actividad reciente</div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <?php while ($act = $actividad->fetch_assoc()): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <i class="bi bi-person-plus text-success"></i>
                                        <span class="ms-2">Nuevo estudiante: <?php echo htmlspecialchars($act['nombre']); ?></span>
                                    </div>
                                    <small class="text-muted">Hoy</small>
                                </li>
                                <?php endwhile; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">Estadísticas de acceso</div>
                        <div class="card-body" style="height: 200px; background: #f8f9fa; display: flex; align-items: center; justify-content: center;">
                            Gráfico de acceso (simulado)
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Control de Usuarios -->
        <div id="usuarios-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">
                    <span>Control de Usuarios</span>
                    <button class="btn btn-sm btn-primary">
                        <i class="bi bi-plus"></i> Nuevo Usuario
                    </button>
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Rol</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $usuarios = $conn->query("SELECT NIE, NOMBRE, APELLIDO, CORREO, ROL, ESTADO FROM personal_registrado");
                            while ($u = $usuarios->fetch_assoc()):
                            ?>
                            <tr>
                                <td><?php echo $u['NIE']; ?></td>
                                <td><?php echo htmlspecialchars($u['NOMBRE'] . ' ' . $u['APELLIDO']); ?></td>
                                <td><?php echo htmlspecialchars($u['CORREO']); ?></td>
                                <td>
                                    <span class="badge 
                                        <?php echo $u['ROL'] === 'Administrador' ? 'bg-danger' : ($u['ROL'] === 'Docente' ? 'bg-info' : 'bg-warning text-dark'); ?>">
                                        <?php echo $u['ROL']; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge <?php echo $u['ESTADO'] === 'Activo' ? 'bg-success' : 'bg-secondary'; ?>">
                                        <?php echo $u['ESTADO']; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const menuItems = document.querySelectorAll('.menu-item');
            const sections = document.querySelectorAll('.content-section');
            menuItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    if (this.querySelector('a').getAttribute('href') === 'logout.php') return;
                    e.preventDefault();
                    menuItems.forEach(i => i.classList.remove('active'));
                    this.classList.add('active');
                    sections.forEach(s => s.style.display = 'none');
                    const target = this.getAttribute('data-target');
                    document.getElementById(`${target}-content`).style.display = 'block';
                    document.querySelector('.page-title').textContent = this.querySelector('span').textContent;
                });
            });
            document.querySelector('.menu-item.active').click();
        });
    </script>
</body>
</html>