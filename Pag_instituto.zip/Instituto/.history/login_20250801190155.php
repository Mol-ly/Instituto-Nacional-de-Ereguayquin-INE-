<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="ruta/al/logo.png">
    <title>Login</title>
    <style>
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #29313DFF; /* Gris oscuro/azul marino oscuro acorde al logo */
            color: #f8f9fa; /* Blanco/gris claro para el texto */
        }
        .container {
            flex: 1 0 auto;
        }
        @media (max-width: 767px) {
            .col-md-4 {
                max-width: 100%;
                flex: 0 0 100%;
            }
            .container {
                margin-top: 2rem !important;
            }
        }
        picture, img {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto 1rem auto;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <picture>
                    <source srcset="imagenes/Logo_del_Gobierno_de_El_Salvador_(2019).svg.png" media="(min-width: 768px)">
                    <source srcset="imagenes/Logo_del_Gobierno_de_El_Salvador_(2019).svg.png" media="(max-width: 767px)">
                    <img src="imagenes/Logo_del_Gobierno_de_El_Salvador_(2019).svg.png" alt="Logo Gobierno El Salvador" style="width: 100%; max-width: 200px; height: auto;">
                </picture>
                <h2 class="mb-4 text-center">LOGIN</h2>
                <form action="procesar_login.php" method="POST">
                    <div class="mb-3">
                        <label for="usuario" class="form-label">Usuario</label>
                        <input type="text" class="form-control" id="usuario" name="usuario" required>
                    </div>
                    <div class="mb-3">
                        <label for="contrasena" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" id="contrasena" name="contrasena" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Entrar</button>
                </form>
            </div>
        </div>
    </div>
    <div>
        <br>
        <?php
        include 'footer.php';
        ?>
    </div>
</body>
</html>