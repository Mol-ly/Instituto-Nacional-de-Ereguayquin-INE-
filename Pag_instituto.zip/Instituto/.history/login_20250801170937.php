<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="ruta/al/logo.png">
    <title>Document</title>
</head>
<body>
    <div class="box">
    <div class="form">
        <h2>🔊 LOGIN ❤️</h2>
    <div class="inputBox">
        <input type="text" required="required">
        <span>Username</span>
      </div>
      <div class="inputBox">
        <input type="password" required="required">
        <span>Password</span>
      </div>
      <div class="buttons">
        <button type="submit">Sign in</button>
      </div>
      <div class="links">
        <a href="#">Forgot Password</a>
        <a href="#">Sign up</a>
      </div>
    </div>
  </div>
</body>
</html>