<?php
// estudiante_panel.php
require_once 'config.php';
session_start();

// Verificar autenticación
if (!isset($_SESSION['user_rol']) || $_SESSION['user_rol'] !== 'ESTUDIANTE') {
    header("Location: login.php");
    exit();
}

$conn = conectarDB();
$nie = $_SESSION['user_nie'];

// Obtener datos del estudiante
$estudiante = [];
$stmt = $conn->prepare("SELECT * FROM personal_registrado WHERE NIE = ?");
$stmt->bind_param("i", $nie);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 1) {
    $estudiante = $result->fetch_assoc();
} else {
    session_destroy();
    header("Location: login.php?error=usuario_no_encontrado");
    exit();
}
$stmt->close();

// Obtener materias del estudiante
$materias = [];
$stmt = $conn->prepare("SELECT MATERIA FROM personal_registrado WHERE NIE = ? AND MATERIA IS NOT NULL");
$stmt->bind_param("i", $nie);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $materias[] = $row['MATERIA'];
}
$stmt->close();

// Obtener notas
$notas = [];
$stmt = $conn->prepare("SELECT * FROM notas WHERE NIE = ?");
$stmt->bind_param("i", $nie);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $notas[$row['MATERIA']] = $row;
}
$stmt->close();

// Calcular promedio general
$promedio = 0;
$total_materias = count($notas);
if ($total_materias > 0) {
    $suma = 0;
    foreach ($notas as $n) {
        $suma += $n['PROMEDIO_FINAL'];
    }
    $promedio = round($suma / $total_materias, 1);
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula Virtual - Estudiante</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --color-primary: #0056b3;
            --color-secondary: #1e293b;
            --color-accent: #0ea5e9;
            --color-text: #333333;
            --color-light: #f8f9fa;
            --color-border: #dee2e6;
            --sidebar-width: 280px;
        }
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f7fa;
            color: var(--color-text);
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar Estilo */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            color: white;
            height: 100vh;
            position: fixed;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            z-index: 1000;
        }
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }
        .student-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        .student-img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--color-accent);
            margin-bottom: 1rem;
        }
        .student-name {
            font-weight: 500;
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
        }
        .student-id {
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.7);
        }
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .menu-item {
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s;
        }
        .menu-item:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }
        .menu-item.active {
            background-color: var(--color-primary);
        }
        .menu-link {
            display: flex;
            align-items: center;
            padding: 1rem 1.5rem;
            color: white;
            text-decoration: none;
            font-weight: 400;
        }
        .menu-link:hover {
            color: white;
        }
        .menu-icon {
            margin-right: 10px;
            font-size: 1.1rem;
        }
        /* Contenido principal */
        .main-content {
            margin-left: var(--sidebar-width);
            flex: 1;
            padding: 2rem;
            background-color: #f8fafc;
        }
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--color-border);
        }
        .page-title {
            font-size: 1.75rem;
            color: var(--color-secondary);
            margin: 0;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
        }
        .card-header {
            background-color: white;
            border-bottom: 1px solid var(--color-border);
            font-weight: 500;
            padding: 1.25rem 1.5rem;
            border-radius: 10px 10px 0 0 !important;
        }
        .table th {
            background-color: #f8f9fa;
            font-weight: 500;
            color: var(--color-secondary);
        }
        .badge {
            font-weight: 500;
            padding: 0.35em 0.65em;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-left: 0;
            }
            .sidebar-menu {
                display: flex;
                flex-wrap: wrap;
            }
            .menu-item {
                flex: 1 0 auto;
                border-bottom: none;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="student-profile">
                <img src="imagenes\Logo_del_Gobierno_de_El_Salvador_(2019).svg.png" alt="Foto del estudiante" class="student-img">
                <div class="student-name"><?php echo htmlspecialchars($_SESSION['user_nombre'] . ' ' . $_SESSION['user_apellido']); ?></div>
                <div class="student-id">ID: <?php echo htmlspecialchars($_SESSION['user_nie']); ?></div>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-item active" data-target="dashboard">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-speedometer2"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="menu-item" data-target="datos">
                <a href="#" class="menu-link">
                    <i class="menu-icon"></i>
                    <span>Datos personales</span>
                </a>
            </li>
            <li class="menu-item" data-target="materias">
                <a href="#" class="menu-link">
                    <i class="menu-icon"></i>
                    <span>Materias</span>
                </a>
            </li>
            <li class="menu-item" data-target="modulos">
                <a href="#" class="menu-link">
                    <i class="menu-icon"></i>
                    <span>Módulos</span>
                </a>
            </li>
            <li class="menu-item" data-target="notas">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-journal-text"></i>
                    <span>Notas</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="logout.php" class="menu-link">
                    <i class="menu-icon bi bi-box-arrow-right"></i>
                    <span>Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="content-header">
            <h1 class="page-title">Dashboard</h1>
            <div class="date-info"><?php echo date('d/m/Y'); ?></div>
        </div>

        <!-- Dashboard -->
        <div id="dashboard-content" class="content-section">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">Resumen académico</div>
                        <div class="card-body">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td>Materias inscritas</td>
                                        <td><?php echo count($materias); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Promedio general</td>
                                        <td><?php echo $promedio > 0 ? $promedio : 'N/A'; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Próximas evaluaciones</td>
                                        <td>2</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">Notificaciones recientes</div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">Nueva tarea en <?php echo !empty($materias) ? $materias[0] : 'Matemáticas'; ?></li>
                                <li class="list-group-item">Calificación publicada en <?php echo !empty($materias) ? $materias[1] ?? $materias[0] : 'Ciencias'; ?></li>
                                <li class="list-group-item">Reunión de padres 15/11</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Datos personales -->
        <div id="datos-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">Información personal</div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tbody>
                            <tr><th>Nombre completo</th><td><?php echo htmlspecialchars($estudiante['NOMBRE'] . ' ' . $estudiante['APELLIDO']); ?></td></tr>
                            <tr><th>Fecha de nacimiento</th><td><?php echo htmlspecialchars($estudiante['FECHA_NACIMIENTO'] ?? 'N/A'); ?></td></tr>
                            <tr><th>DNI</th><td><?php echo htmlspecialchars($estudiante['DNI'] ?? 'N/A'); ?></td></tr>
                            <tr><th>Dirección</th><td><?php echo htmlspecialchars($estudiante['DIRECCION'] ?? 'N/A'); ?></td></tr>
                            <tr><th>Teléfono</th><td><?php echo htmlspecialchars($estudiante['TELEFONO'] ?? 'N/A'); ?></td></tr>
                            <tr><th>Correo electrónico</th><td><?php echo htmlspecialchars($estudiante['CORREO']); ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Materias -->
        <div id="materias-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">Materias inscritas</div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Materia</th>
                                <th>Docente</th>
                                <th>Horario</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($materias as $materia): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($materia); ?></td>
                                <td>
                                    <?php
                                    $stmt = $conn->prepare("SELECT NOMBRE, APELLIDO FROM personal_registrado WHERE MATERIA = ? AND ROL = 'Docente' LIMIT 1");
                                    $stmt->bind_param("s", $materia);
                                    $stmt->execute();
                                    $docente = $stmt->get_result()->fetch_assoc();
                                    echo $docente ? htmlspecialchars($docente['NOMBRE'] . ' ' . $docente['APELLIDO']) : 'No asignado';
                                    ?>
                                </td>
                                <td>Lunes y Miércoles 8:00-10:00</td>
                                <td><span class="badge bg-success">Activa</span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Módulos -->
        <div id="modulos-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">Módulos disponibles</div>
                <div class="card-body">
                    <div class="row">
                        <?php foreach ($materias as $materia): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100">
                                <div class="card-header bg-primary text-white">
                                    <?php echo htmlspecialchars($materia); ?> - Unidad 1
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title">Introducción</h5>
                                    <p class="card-text">Contenido básico del módulo.</p>
                                    <a href="#" class="btn btn-sm btn-outline-primary">Acceder</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Notas -->
        <div id="notas-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">Calificaciones</div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Materia</th>
                                <th>Parcial 1</th>
                                <th>Parcial 2</th>
                                <th>Parcial 3</th>
                                <th>Final</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($materias as $materia): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($materia); ?></td>
                                <td><?php echo $notas[$materia]['PERIODO_1'] ?? '-'; ?></td>
                                <td><?php echo $notas[$materia]['PERIODO_2'] ?? '-'; ?></td>
                                <td><?php echo $notas[$materia]['PERIODO_3'] ?? '-'; ?></td>
                                <td><?php echo $notas[$materia]['PROMEDIO_FINAL'] ?? '-'; ?></td>
                                <td>
                                    <?php
                                    $final = $notas[$materia]['PROMEDIO_FINAL'] ?? 0;
                                    if ($final >= 6) {
                                        echo '<span class="badge bg-success">Aprobado</span>';
                                    } elseif ($final > 0) {
                                        echo '<span class="badge bg-warning text-dark">Reprobado</span>';
                                    } else {
                                        echo '<span class="badge bg-secondary">En curso</span>';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const menuItems = document.querySelectorAll('.menu-item');
            const sections = document.querySelectorAll('.content-section');
            menuItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    if (this.querySelector('a').getAttribute('href') === 'logout.php') return;
                    e.preventDefault();
                    menuItems.forEach(i => i.classList.remove('active'));
                    this.classList.add('active');
                    sections.forEach(s => s.style.display = 'none');
                    const target = this.getAttribute('data-target');
                    document.getElementById(`${target}-content`).style.display = 'block';
                    document.querySelector('.page-title').textContent = this.querySelector('span').textContent;
                });
            });
            document.querySelector('.menu-item.active').click();
        });
    </script>
</body>
</html>