<footer style="background:#f8f9fa; padding:20px 0; text-align:center; border-top:1px solid #e0e0e0;">
    <p style="margin:0; color:#555;">&copy; <?php echo date('Y'); ?> Instituto Educativo. Todos los derechos reservados.</p>
</footer>

