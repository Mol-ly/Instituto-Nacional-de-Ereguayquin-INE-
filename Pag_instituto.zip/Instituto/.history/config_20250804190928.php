<?php
// config.php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'instituto');

function conectarDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die("Error: " . $conn->connect_error);
    }
    $conn->set_charset("utf8");
    return $conn;
}

function limpiarDatos($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}


?>
