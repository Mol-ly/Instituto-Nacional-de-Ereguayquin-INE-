

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Docente - Sistema Académico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --color-primary: #0056b3;
            --color-secondary: #1e293b;
            --color-accent: #0ea5e9;
            --color-text: #333333;
            --color-light: #f8f9fa;
            --color-border: #dee2e6;
            --sidebar-width: 280px;
        }
        
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f7fa;
            color: var(--color-text);
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Estilo */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            color: white;
            height: 100vh;
            position: fixed;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }
        
        .teacher-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .teacher-img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--color-accent);
            margin-bottom: 1rem;
        }
        
        .teacher-name {
            font-weight: 500;
            font-size: 1.1rem;
            margin-bottom: 0.25rem;
        }
        
        .teacher-position {
            font-size: 0.85rem;
            background-color: var(--color-primary);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            margin-bottom: 0.5rem;
        }
        
        .teacher-id {
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.7);
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .menu-item {
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s;
        }
        
        .menu-item:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }
        
        .menu-item.active {
            background-color: var(--color-primary);
        }
        
        .menu-link {
            display: flex;
            align-items: center;
            padding: 1rem 1.5rem;
            color: white;
            text-decoration: none;
            font-weight: 400;
        }
        
        .menu-link:hover {
            color: white;
        }
        
        .menu-icon {
            margin-right: 10px;
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        
        /* Contenido principal */
        .main-content {
            margin-left: var(--sidebar-width);
            flex: 1;
            padding: 2rem;
            background-color: #f8fafc;
        }
        
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--color-border);
        }
        
        .page-title {
            font-size: 1.75rem;
            color: var(--color-secondary);
            margin: 0;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
        }
        
        .card-header {
            background-color: white;
            border-bottom: 1px solid var(--color-border);
            font-weight: 500;
            padding: 1.25rem 1.5rem;
            border-radius: 10px 10px 0 0 !important;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table th {
            background-color: #f8f9fa;
            font-weight: 500;
            color: var(--color-secondary);
        }
        
        .badge {
            font-weight: 500;
            padding: 0.35em 0.65em;
        }
        
        .form-select, .form-control {
            border-radius: 6px;
            padding: 0.5rem 1rem;
        }
        
        .btn-primary {
            background-color: var(--color-primary);
            border: none;
            padding: 0.5rem 1.25rem;
            border-radius: 6px;
        }
        
        .attendance-btn {
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            border-radius: 50%;
        }
        
        .btn-present {
            background-color: #28a745;
            color: white;
        }
        
        .btn-absent {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-justified {
            background-color: #ffc107;
            color: #212529;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .sidebar-menu {
                display: flex;
                flex-wrap: wrap;
            }
            
            .menu-item {
                flex: 1 0 auto;
                border-bottom: none;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="teacher-profile">
                <img src="imagenes/teacher_avatar.jpg" alt="Foto del docente" class="teacher-img">
                <div class="teacher-name">Prof. Carlos Martínez</div>
                <div class="teacher-position">Docente Titular</div>
                <div class="teacher-id">ID: DOC2023005</div>
            </div>
        </div>
        
        <ul class="sidebar-menu">
            <li class="menu-item active" data-target="dashboard">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-speedometer2"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="menu-item" data-target="datos">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-person"></i>
                    <span>Datos personales</span>
                </a>
            </li>
            <li class="menu-item" data-target="asistencias">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-clipboard-check"></i>
                    <span>Registro de asistencias</span>
                </a>
            </li>
            <li class="menu-item" data-target="notas">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-journal-text"></i>
                    <span>Registro de notas</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="logout.php" class="menu-link">
                    <i class="menu-icon bi bi-box-arrow-right"></i>
                    <span>Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="content-header">
            <h1 class="page-title">Dashboard</h1>
            <div class="date-info"><?php echo date('d/m/Y'); ?></div>
        </div>
        
        <!-- Dashboard Content (default view) -->
        <div id="dashboard-content" class="content-section">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            Resumen de actividades
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td>Materias asignadas</td>
                                        <td>3</td>
                                    </tr>
                                    <tr>
                                        <td>Estudiantes a cargo</td>
                                        <td>75</td>
                                    </tr>
                                    <tr>
                                        <td>Próximas clases</td>
                                        <td>2 hoy</td>
                                    </tr>
                                    <tr>
                                        <td>Evaluaciones pendientes</td>
                                        <td>3</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            Calendario académico
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <strong>Hoy: <?php echo date('d/m/Y'); ?></strong>
                            </div>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span>Reunión de departamento</span>
                                    <span class="badge bg-primary">10:00 AM</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span>Clase: Matemáticas Avanzadas</span>
                                    <span class="badge bg-primary">2:00 PM</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span>Entrega de planificaciones</span>
                                    <span class="badge bg-warning text-dark">Viernes</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card mt-4">
                <div class="card-header">
                    Materias asignadas
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 mb-4">
                            <div class="card h-100">
                                <div class="card-header bg-primary text-white">
                                    Matemáticas Avanzadas
                                </div>
                                <div class="card-body">
                                    <p><strong>Código:</strong> MAT-101</p>
                                    <p><strong>Horario:</strong> Lunes y Miércoles 2:00-4:00 PM</p>
                                    <p><strong>Estudiantes:</strong> 25</p>
                                    <a href="#" class="btn btn-sm btn-outline-primary">Ver detalles</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100">
                                <div class="card-header bg-success text-white">
                                    Álgebra Lineal
                                </div>
                                <div class="card-body">
                                    <p><strong>Código:</strong> MAT-205</p>
                                    <p><strong>Horario:</strong> Martes y Jueves 8:00-10:00 AM</p>
                                    <p><strong>Estudiantes:</strong> 30</p>
                                    <a href="#" class="btn btn-sm btn-outline-success">Ver detalles</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100">
                                <div class="card-header bg-info text-white">
                                    Geometría Analítica
                                </div>
                                <div class="card-body">
                                    <p><strong>Código:</strong> MAT-110</p>
                                    <p><strong>Horario:</strong> Viernes 7:00-11:00 AM</p>
                                    <p><strong>Estudiantes:</strong> 20</p>
                                    <a href="#" class="btn btn-sm btn-outline-info">Ver detalles</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Datos Personales Content -->
        <div id="datos-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">
                    Información personal
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th width="30%">Nombre completo</th>
                                <td>Carlos Enrique Martínez González</td>
                            </tr>
                            <tr>
                                <th>Fecha de nacimiento</th>
                                <td>12/08/1980</td>
                            </tr>
                            <tr>
                                <th>DNI</th>
                                <td>02345678-9</td>
                            </tr>
                            <tr>
                                <th>Cargo</th>
                                <td>Docente Titular - Departamento de Matemáticas</td>
                            </tr>
                            <tr>
                                <th>Especialidad</th>
                                <td>Matemáticas Puras</td>
                            </tr>
                            <tr>
                                <th>Años de servicio</th>
                                <td>12</td>
                            </tr>
                            <tr>
                                <th>Dirección</th>
                                <td>Colonia Escalón, Calle Las Magnolias #45</td>
                            </tr>
                            <tr>
                                <th>Teléfono</th>
                                <td>7890-1234</td>
                            </tr>
                            <tr>
                                <th>Correo electrónico</th>
                                <td>c.martinez@instituto.edu.sv</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Asistencias Content -->
        <div id="asistencias-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">
                    <span>Registro de asistencias</span>
                    <div>
                        <select class="form-select form-select-sm" style="width: auto; display: inline-block;">
                            <option>Matemáticas Avanzadas</option>
                            <option>Álgebra Lineal</option>
                            <option>Geometría Analítica</option>
                        </select>
                        <input type="date" class="form-control form-control-sm" style="width: auto; display: inline-block;">
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Estudiante</th>
                                <th>Asistencia</th>
                                <th>Observaciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>María Alejandra Rodríguez Pérez</td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-present attendance-btn" title="Presente">P</button>
                                        <button class="btn btn-absent attendance-btn" title="Ausente">A</button>
                                        <button class="btn btn-justified attendance-btn" title="Justificado">J</button>
                                    </div>
                                </td>
                                <td>
                                    <input type="text" class="form-control form-control-sm" placeholder="Notas">
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Juan Carlos López Méndez</td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-present attendance-btn" title="Presente">P</button>
                                        <button class="btn btn-absent attendance-btn" title="Ausente">A</button>
                                        <button class="btn btn-justified attendance-btn" title="Justificado">J</button>
                                    </div>
                                </td>
                                <td>
                                    <input type="text" class="form-control form-control-sm" placeholder="Notas">
                                </td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Ana Patricia Sánchez García</td>
                                <td>
                                    <div class="btn-group">
                                        <button class="btn btn-present attendance-btn" title="Presente">P</button>
                                        <button class="btn btn-absent attendance-btn" title="Ausente">A</button>
                                        <button class="btn btn-justified attendance-btn" title="Justificado">J</button>
                                    </div>
                                </td>
                                <td>
                                    <input type="text" class="form-control form-control-sm" placeholder="Notas">
                                </td>
                            </tr>
                            <!-- Más filas de estudiantes -->
                        </tbody>
                    </table>
                    <div class="text-end mt-3">
                        <button class="btn btn-primary">Guardar asistencias</button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Notas Content -->
        <div id="notas-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">
                    <span>Registro de notas</span>
                    <div>
                        <select class="form-select form-select-sm" style="width: auto; display: inline-block;">
                            <option>Matemáticas Avanzadas</option>
                            <option>Álgebra Lineal</option>
                            <option>Geometría Analítica</option>
                        </select>
                        <select class="form-select form-select-sm" style="width: auto; display: inline-block;">
                            <option>Primer Parcial</option>
                            <option>Segundo Parcial</option>
                            <option>Tercer Parcial</option>
                            <option>Examen Final</option>
                        </select>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Estudiante</th>
                                <th>Nota</th>
                                <th>Comentarios</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>María Alejandra Rodríguez Pérez</td>
                                <td>
                                    <input type="number" min="0" max="10" step="0.1" class="form-control" style="width: 80px;">
                                </td>
                                <td>
                                    <input type="text" class="form-control" placeholder="Observaciones">
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Juan Carlos López Méndez</td>
                                <td>
                                    <input type="number" min="0" max="10" step="0.1" class="form-control" style="width: 80px;">
                                </td>
                                <td>
                                    <input type="text" class="form-control" placeholder="Observaciones">
                                </td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Ana Patricia Sánchez García</td>
                                <td>
                                    <input type="number" min="0" max="10" step="0.1" class="form-control" style="width: 80px;">
                                </td>
                                <td>
                                    <input type="text" class="form-control" placeholder="Observaciones">
                                </td>
                            </tr>
                            <!-- Más filas de estudiantes -->
                        </tbody>
                    </table>
                    <div class="text-end mt-3">
                        <button class="btn btn-primary">Guardar notas</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Navegación del sidebar
        document.addEventListener('DOMContentLoaded', function() {
            const menuItems = document.querySelectorAll('.menu-item');
            const contentSections = document.querySelectorAll('.content-section');
            
            menuItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    if(this.querySelector('a').getAttribute('href') === 'logout.php') return;
                    
                    e.preventDefault();
                    
                    // Remover clase active de todos los items
                    menuItems.forEach(i => i.classList.remove('active'));
                    
                    // Agregar clase active al item clickeado
                    this.classList.add('active');
                    
                    // Ocultar todas las secciones de contenido
                    contentSections.forEach(section => {
                        section.style.display = 'none';
                    });
                    
                    // Mostrar la sección correspondiente
                    const target = this.getAttribute('data-target');
                    if(target) {
                        document.getElementById(`${target}-content`).style.display = 'block';
                        
                        // Actualizar título de la página
                        const pageTitle = document.querySelector('.page-title');
                        const menuText = this.querySelector('span').textContent;
                        pageTitle.textContent = menuText;
                    }
                });
            });
            
            // Mostrar dashboard por defecto
            document.querySelector('.menu-item.active').click();
            
            // Manejo de botones de asistencia
            document.querySelectorAll('.attendance-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    // Reset all buttons in group
                    this.parentNode.querySelectorAll('.attendance-btn').forEach(b => {
                        b.classList.remove('active');
                    });
                    
                    // Mark clicked button as active
                    this.classList.add('active');
                });
            });
        });
    </script>
</body>
</html>
<?php
        include 'footer.php';
        ?>