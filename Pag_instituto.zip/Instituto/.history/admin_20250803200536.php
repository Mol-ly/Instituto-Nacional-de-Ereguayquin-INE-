<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración - Sistema Académico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --color-primary: #0056b3;
            --color-secondary: #1e293b;
            --color-accent: #0ea5e9;
            --color-danger: #dc3545;
            --color-success: #28a745;
            --color-warning: #ffc107;
            --color-text: #333333;
            --color-light: #f8f9fa;
            --color-border: #dee2e6;
            --sidebar-width: 280px;
        }
        
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f7fa;
            color: var(--color-text);
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Estilo */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            color: white;
            height: 100vh;
            position: fixed;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }
        
        .admin-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .admin-img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--color-accent);
            margin-bottom: 1rem;
        }
        
        .admin-name {
            font-weight: 500;
            font-size: 1.1rem;
            margin-bottom: 0.25rem;
        }
        
        .admin-role {
            font-size: 0.85rem;
            background-color: var(--color-danger);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            margin-bottom: 0.5rem;
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .menu-item {
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s;
        }
        
        .menu-item:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }
        
        .menu-item.active {
            background-color: var(--color-primary);
        }
        
        .menu-link {
            display: flex;
            align-items: center;
            padding: 1rem 1.5rem;
            color: white;
            text-decoration: none;
            font-weight: 400;
        }
        
        .menu-link:hover {
            color: white;
        }
        
        .menu-icon {
            margin-right: 10px;
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        
        /* Contenido principal */
        .main-content {
            margin-left: var(--sidebar-width);
            flex: 1;
            padding: 2rem;
            background-color: #f8fafc;
        }
        
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--color-border);
        }
        
        .page-title {
            font-size: 1.75rem;
            color: var(--color-secondary);
            margin: 0;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
        }
        
        .card-header {
            background-color: white;
            border-bottom: 1px solid var(--color-border);
            font-weight: 500;
            padding: 1.25rem 1.5rem;
            border-radius: 10px 10px 0 0 !important;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table th {
            background-color: #f8f9fa;
            font-weight: 500;
            color: var(--color-secondary);
        }
        
        .badge {
            font-weight: 500;
            padding: 0.35em 0.65em;
        }
        
        .btn-icon {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            border-radius: 6px;
        }
        
        .search-box {
            position: relative;
            max-width: 300px;
        }
        
        .search-box .form-control {
            padding-left: 40px;
            border-radius: 20px;
        }
        
        .search-box .bi {
            position: absolute;
            left: 15px;
            top: 10px;
            color: #6c757d;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .sidebar-menu {
                display: flex;
                flex-wrap: wrap;
            }
            
            .menu-item {
                flex: 1 0 auto;
                border-bottom: none;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="admin-profile">
                <img src="imagenes/admin_avatar.jpg" alt="Foto del administrador" class="admin-img">
                <div class="admin-name">Lic. Roberto Sánchez</div>
                <div class="admin-role">Administrador</div>
            </div>
        </div>
        
        <ul class="sidebar-menu">
            <li class="menu-item active" data-target="dashboard">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-speedometer2"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="menu-item" data-target="usuarios">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-people"></i>
                    <span>Control de Usuarios</span>
                </a>
            </li>
            <li class="menu-item" data-target="materias">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-journal-bookmark"></i>
                    <span>Gestión de Materias</span>
                </a>
            </li>
            <li class="menu-item" data-target="estudiantes">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-person-video2"></i>
                    <span>Registro de Estudiantes</span>
                </a>
            </li>
            <li class="menu-item" data-target="docentes">
                <a href="#" class="menu-link">
                    <i class="menu-icon bi bi-person-badge"></i>
                    <span>Registro de Docentes</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="logout.php" class="menu-link">
                    <i class="menu-icon bi bi-box-arrow-right"></i>
                    <span>Cerrar sesión</span>
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="content-header">
            <h1 class="page-title">Dashboard</h1>
            <div class="date-info"><?php echo date('d/m/Y'); ?></div>
        </div>
        
        <!-- Dashboard Content (default view) -->
        <div id="dashboard-content" class="content-section">
            <div class="row">
                <div class="col-md-3 mb-4">
                    <div class="card border-primary">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-2">Usuarios</h6>
                                    <h3 class="mb-0">142</h3>
                                </div>
                                <div class="bg-primary bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-people text-primary" style="font-size: 1.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card border-success">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-2">Estudiantes</h6>
                                    <h3 class="mb-0">1,250</h3>
                                </div>
                                <div class="bg-success bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-person-video2 text-success" style="font-size: 1.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card border-info">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-2">Docentes</h6>
                                    <h3 class="mb-0">48</h3>
                                </div>
                                <div class="bg-info bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-person-badge text-info" style="font-size: 1.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="card border-warning">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="text-muted mb-2">Materias</h6>
                                    <h3 class="mb-0">36</h3>
                                </div>
                                <div class="bg-warning bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-journal-bookmark text-warning" style="font-size: 1.5rem;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <span>Actividad reciente</span>
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <i class="bi bi-person-plus text-success"></i>
                                        <span class="ms-2">Nuevo estudiante registrado</span>
                                    </div>
                                    <small class="text-muted">Hace 15 min</small>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <i class="bi bi-journal-plus text-primary"></i>
                                        <span class="ms-2">Nueva materia creada</span>
                                    </div>
                                    <small class="text-muted">Hace 2 horas</small>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <i class="bi bi-shield-lock text-warning"></i>
                                        <span class="ms-2">Actualización de seguridad</span>
                                    </div>
                                    <small class="text-muted">Ayer</small>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <i class="bi bi-calendar-event text-info"></i>
                                        <span class="ms-2">Nuevo calendario académico</span>
                                    </div>
                                    <small class="text-muted">3 días atrás</small>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <span>Estadísticas de acceso</span>
                        </div>
                        <div class="card-body">
                            <div style="height: 200px; background-color: #f8f9fa; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: #6c757d;">
                                Gráfico de accesos (simulado)
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Usuarios Content -->
        <div id="usuarios-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">
                    <span>Control de Usuarios</span>
                    <div class="d-flex">
                        <div class="search-box me-2">
                            <i class="bi bi-search"></i>
                            <input type="text" class="form-control form-control-sm" placeholder="Buscar usuario...">
                        </div>
                        <button class="btn btn-sm btn-primary">
                            <i class="bi bi-plus"></i> Nuevo Usuario
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Rol</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>USR1001</td>
                                <td>Roberto Sánchez</td>
                                <td>admin@instituto.edu.sv</td>
                                <td><span class="badge bg-danger">Administrador</span></td>
                                <td><span class="badge bg-success">Activo</span></td>
                                <td>
                                    <button class="btn-icon btn-sm btn-outline-primary me-1" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-danger" title="Eliminar">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>USR2005</td>
                                <td>Carlos Martínez</td>
                                <td>c.martinez@instituto.edu.sv</td>
                                <td><span class="badge bg-info">Docente</span></td>
                                <td><span class="badge bg-success">Activo</span></td>
                                <td>
                                    <button class="btn-icon btn-sm btn-outline-primary me-1" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-danger" title="Eliminar">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>USR3056</td>
                                <td>María Rodríguez</td>
                                <td>m.rodriguez@instituto.edu.sv</td>
                                <td><span class="badge bg-warning text-dark">Estudiante</span></td>
                                <td><span class="badge bg-success">Activo</span></td>
                                <td>
                                    <button class="btn-icon btn-sm btn-outline-primary me-1" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-danger" title="Eliminar">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" tabindex="-1">Anterior</a>
                            </li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Siguiente</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        
        <!-- Materias Content -->
        <div id="materias-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">
                    <span>Gestión de Materias</span>
                    <button class="btn btn-sm btn-primary">
                        <i class="bi bi-plus"></i> Nueva Materia
                    </button>
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Nombre</th>
                                <th>Área</th>
                                <th>Docente</th>
                                <th>Horas</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>MAT-101</td>
                                <td>Matemáticas Avanzadas</td>
                                <td>Matemáticas</td>
                                <td>Carlos Martínez</td>
                                <td>80</td>
                                <td>
                                    <button class="btn-icon btn-sm btn-outline-primary me-1" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-danger" title="Eliminar">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>FIS-201</td>
                                <td>Física Moderna</td>
                                <td>Ciencias</td>
                                <td>Laura González</td>
                                <td>60</td>
                                <td>
                                    <button class="btn-icon btn-sm btn-outline-primary me-1" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-danger" title="Eliminar">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>LEN-110</td>
                                <td>Lenguaje y Literatura</td>
                                <td>Humanidades</td>
                                <td>Jorge Ramírez</td>
                                <td>70</td>
                                <td>
                                    <button class="btn-icon btn-sm btn-outline-primary me-1" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-danger" title="Eliminar">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Estudiantes Content -->
        <div id="estudiantes-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">
                    <span>Registro de Estudiantes</span>
                    <div class="d-flex">
                        <div class="search-box me-2">
                            <i class="bi bi-search"></i>
                            <input type="text" class="form-control form-control-sm" placeholder="Buscar estudiante...">
                        </div>
                        <button class="btn btn-sm btn-primary">
                            <i class="bi bi-plus"></i> Nuevo Estudiante
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Grado</th>
                                <th>Edad</th>
                                <th>Contacto</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>EST2023001</td>
                                <td>María Alejandra Rodríguez Pérez</td>
                                <td>11° A</td>
                                <td>17</td>
                                <td>maria.rodriguez@instituto.edu.sv</td>
                                <td><span class="badge bg-success">Activo</span></td>
                                <td>
                                    <button class="btn-icon btn-sm btn-outline-primary me-1" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-info me-1" title="Ver">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-danger" title="Eliminar">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>EST2023002</td>
                                <td>Juan Carlos López Méndez</td>
                                <td>10° B</td>
                                <td>16</td>
                                <td>juan.lopez@instituto.edu.sv</td>
                                <td><span class="badge bg-success">Activo</span></td>
                                <td>
                                    <button class="btn-icon btn-sm btn-outline-primary me-1" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-info me-1" title="Ver">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-danger" title="Eliminar">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Docentes Content -->
        <div id="docentes-content" class="content-section" style="display:none;">
            <div class="card">
                <div class="card-header">
                    <span>Registro de Docentes</span>
                    <div class="d-flex">
                        <div class="search-box me-2">
                            <i class="bi bi-search"></i>
                            <input type="text" class="form-control form-control-sm" placeholder="Buscar docente...">
                        </div>
                        <button class="btn btn-sm btn-primary">
                            <i class="bi bi-plus"></i> Nuevo Docente
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Especialidad</th>
                                <th>Años de servicio</th>
                                <th>Contacto</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>DOC2023005</td>
                                <td>Carlos Enrique Martínez González</td>
                                <td>Matemáticas</td>
                                <td>12</td>
                                <td>c.martinez@instituto.edu.sv</td>
                                <td><span class="badge bg-success">Activo</span></td>
                                <td>
                                    <button class="btn-icon btn-sm btn-outline-primary me-1" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-info me-1" title="Ver">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-danger" title="Eliminar">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>DOC2023012</td>
                                <td>Laura Patricia González Ramírez</td>
                                <td>Ciencias Naturales</td>
                                <td>8</td>
                                <td>l.gonzalez@instituto.edu.sv</td>
                                <td><span class="badge bg-success">Activo</span></td>
                                <td>
                                    <button class="btn-icon btn-sm btn-outline-primary me-1" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-info me-1" title="Ver">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <button class="btn-icon btn-sm btn-outline-danger" title="Eliminar">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Navegación del sidebar
        document.addEventListener('DOMContentLoaded', function() {
            const menuItems = document.querySelectorAll('.menu-item');
            const contentSections = document.querySelectorAll('.content-section');
            
            menuItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    if(this.querySelector('a').getAttribute('href') === 'logout.php') return;
                    
                    e.preventDefault();
                    
                    // Remover clase active de todos los items
                    menuItems.forEach(i => i.classList.remove('active'));
                    
                    // Agregar clase active al item clickeado
                    this.classList.add('active');
                    
                    // Ocultar todas las secciones de contenido
                    contentSections.forEach(section => {
                        section.style.display = 'none';
                    });
                    
                    // Mostrar la sección correspondiente
                    const target = this.getAttribute('data-target');
                    if(target) {
                        document.getElementById(`${target}-content`).style.display = 'block';
                        
                        // Actualizar título de la página
                        const pageTitle = document.querySelector('.page-title');
                        const menuText = this.querySelector('span').textContent;
                        pageTitle.textContent = menuText;
                    }
                });
            });
            
            // Mostrar dashboard por defecto
            document.querySelector('.menu-item.active').click();
        });
    </script>
</body>
</html>
<?php
        include 'footer.php';
        ?>