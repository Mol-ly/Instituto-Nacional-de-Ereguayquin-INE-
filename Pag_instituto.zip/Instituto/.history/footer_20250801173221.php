<?php
/* Para conectar este footer a otros documentos, simplemente incluye este archivo usando: 
    include 'footer.php'; 
    o 
    require 'footer.php'; 
    en los archivos donde quieras mostrar el footer. */
?>

